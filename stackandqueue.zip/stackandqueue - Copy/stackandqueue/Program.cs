﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stackandqueue
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] Cars = new string[5];
            for (int i = 0; i < Cars.Length; i++)
            {
                Console.Write("Enter name: ");
                Cars[i] = Console.ReadLine();
            }
            Console.WriteLine("=====print queue(FIFO)====");
            foreach (string Car in Cars)
            {
                Console.WriteLine(Car);
            }
            Console.WriteLine("====print stack(LIFO)====");
            for (int i = Cars.Length - 1; i >= 0; i--)
            {
                Console.WriteLine(Cars[i]);
            }
            Console.WriteLine("====sort====");
            Array.Sort(Cars);
            foreach (string i in Cars)
            {
                Console.WriteLine(i);
            }

            Console.ReadKey();
        }

    }

}
       